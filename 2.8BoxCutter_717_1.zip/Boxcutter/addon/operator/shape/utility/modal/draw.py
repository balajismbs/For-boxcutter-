# from ... import shape as _shape
from .. import lattice, mesh


def shape(op, context, event, index=-1):
    bc = context.scene.bc

    if op.shape_type != 'NGON':
        lattice.draw(op, context, event)
    else:
        mesh.draw(op, context, event, index=index)

    points = bc.lattice.data.points
    location_z = None
    for point in lattice.back:
        if not location_z:
            location_z = points[point].co_deform.z
        points[point].co_deform.z = location_z if location_z < -lattice.thickness_clamp(context) else -lattice.thickness_clamp(context)
