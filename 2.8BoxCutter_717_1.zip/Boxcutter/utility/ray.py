import bpy

from math import radians
from mathutils import Matrix, Vector

from . import addon
from . view3d import location2d_to_origin3d, location2d_to_vector3d


class cast:
    origin: Vector = (0, 0)
    direction: Vector = (0, 0)


    def __new__(self, x, y, selected=False, obj=None, mesh_data=None, use_copy=False, transform_by=None, types={'MESH'}):
        context = bpy.context
        self.origin = location2d_to_origin3d(x, y)
        self.direction = location2d_to_vector3d(x, y)
        self.obj = obj
        self.mesh_data = mesh_data
        self.use_copy = use_copy
        self.transform_by = transform_by

        if obj:
            return self.object(self, context)

        elif mesh_data:
            return self.mesh(self, context)

        return self.scene(self, context, selected)


    def object(self, context):
        # returns hit, location, normal, index
        if self.transform_by:
            self.obj.data.transform(self.transform_by)
        return self.obj.ray_cast(self.origin, self.direction,
                depsgraph = bpy.context.evaluated_depsgraph_get())


    def mesh(self, context):
        obj = bpy.data.objects.new(name='snap_mesh', object_data=self.mesh_data)
        bpy.context.scene.collection.objects.link(obj)

        if self.use_copy:
            obj.data = obj.data.copy()
            obj.data.bc.removeable = True

        if self.transform_by:
            obj.data.transform(self.transform_by)

        hit, location, normal, index = obj.ray_cast(self.origin, self.direction, depsgraph=bpy.context.evaluated_depsgraph_get())

        bpy.data.objects.remove(obj)

        del obj

        return hit, location, normal, index


    def scene(self, context, selected, types={'MESH'}):
        depsgraph = context.view_layer.depsgraph if bpy.app.version > (2, 90, 0) else context.view_layer
        hit, location, normal, index, object, matrix = context.scene.ray_cast(depsgraph, self.origin, self.direction)

        hidden = []
        selection = {obj for obj in context.selected_objects if obj.type in types}

        while True:
            if hit and object not in selection:
                hidden.append(object)
                object.hide_set(True)

                hit, location, normal, index, object, matrix = context.scene.ray_cast(depsgraph, self.origin, self.direction)

            else:
                break

        for obj in hidden:
            obj.hide_set(False)

        return hit, location, normal, index, object, matrix
